addEventListener('fetch', event => {
  event.respondWith(handleRequest(event.request, event));
});

const MB = 1024 * 1024;

function isTruthy(value) {
  const str = String(value || '').trim().toLowerCase();
  return ['1', 'true', 'yes', 'on'].includes(str);
}

const ALLOW_FALLBACK =
  typeof globalThis !== 'undefined' && globalThis.ALLOW_FALLBACK !== undefined
    ? isTruthy(globalThis.ALLOW_FALLBACK)
    : true;

const MAX_RAW_FETCH_BYTES = 70 * MB;
const MAX_TRACKED_DOMAINS = 500;
const MAX_RESPONSE_SAMPLES = 10;

const ENABLE_MIRROR_RACING =
  typeof globalThis !== 'undefined' && globalThis.ENABLE_MIRROR_RACING !== undefined
    ? isTruthy(globalThis.ENABLE_MIRROR_RACING)
    : false;

const VERCEL_TIMEOUT_MS = (() => {
  const raw =
    typeof globalThis !== 'undefined' && globalThis.WORKER_VERCEL_TIMEOUT_MS !== undefined
      ? globalThis.WORKER_VERCEL_TIMEOUT_MS
      : 52000;

  const n = parseInt(raw, 10);
  return Number.isFinite(n) && n > 0 ? n : 52000;
})();

function jsonResponse(body, init = {}) {
  const headers = new Headers(init.headers || {});

  if (!headers.has('Content-Type')) {
    headers.set('Content-Type', 'application/json; charset=utf-8');
  }

  if (!headers.has('Cache-Control')) {
    headers.set('Cache-Control', 'no-store');
  }

  return new Response(JSON.stringify(body), {
    status: init.status || 200,
    statusText: init.statusText,
    headers
  });
}

async function safeCompare(a, b) {
  if (typeof a !== 'string' || typeof b !== 'string' || a.length === 0 || b.length === 0) {
    return false;
  }

  try {
    const enc = new TextEncoder();

    const [hashA, hashB] = await Promise.all([
      crypto.subtle.digest('SHA-256', enc.encode(a)),
      crypto.subtle.digest('SHA-256', enc.encode(b))
    ]);

    const bytesA = new Uint8Array(hashA);
    const bytesB = new Uint8Array(hashB);

    let diff = 0;

    for (let i = 0; i < bytesA.length; i++) {
      diff |= bytesA[i] ^ bytesB[i];
    }

    return diff === 0;
  } catch {
    return false;
  }
}

function sanitizeError(err) {
  let msg = err?.message ? String(err.message) : 'Unknown error';
  msg = msg.replace(/\?[^\s]*/g, '');
  msg = msg.replace(/(api[_-]?key|apikey|api|key|token|secret|password)=([^\s&]*)/gi, '$1=[REDACTED]');
  return msg;
}

function sanitizeUrl(url) {
  try {
    const u = new URL(url);
    return u.origin + '/*';
  } catch {
    return String(url).split('?')[0].split('/').slice(0, 3).join('/') + '/*';
  }
}

function emitTelemetry(eventName, data = {}) {
  try {
    console.log(JSON.stringify({
      event: eventName,
      timestamp: Date.now(),
      ...data
    }));
  } catch {}
}

function normalizeBaseUrl(base) {
  return String(base || '').trim().replace(/\/+$/, '');
}

function joinUrl(base, search) {
  return normalizeBaseUrl(base) + search;
}

function getCacheVersion() {
  return typeof CACHE_VERSION !== 'undefined' && CACHE_VERSION
    ? String(CACHE_VERSION)
    : '1';
}

async function fetchWithTimeout(request, timeoutMs) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const response = await fetch(request, {
      signal: controller.signal
    });

    clearTimeout(timer);
    return response;
  } catch (err) {
    clearTimeout(timer);
    throw err;
  }
}

const TARPIT_IMAGE_B64 = 'R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7';

function base64ToUint8(base64) {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);

  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }

  return bytes;
}

const TARPIT_IMAGE = base64ToUint8(TARPIT_IMAGE_B64);

function createTarpitStream(durationMs = 5000, intervalMs = 250) {
  const totalTicks = Math.max(1, Math.floor(durationMs / intervalMs));
  let tick = 0;
  let offset = 0;

  const chunkSize = Math.max(
    1,
    Math.ceil(TARPIT_IMAGE.length / totalTicks)
  );

  return new ReadableStream({
    async pull(controller) {
      if (tick >= totalTicks || offset >= TARPIT_IMAGE.length) {
        controller.close();
        return;
      }

      await new Promise(resolve => setTimeout(resolve, intervalMs));

      const end = Math.min(TARPIT_IMAGE.length, offset + chunkSize);
      controller.enqueue(TARPIT_IMAGE.slice(offset, end));

      offset = end;
      tick++;

      if (tick >= totalTicks || offset >= TARPIT_IMAGE.length) {
        controller.close();
      }
    }
  });
}

// EPHEMERAL ISOLATE STATE:
// Cloudflare Workers state stored in module scope is per-isolate.
// It is not globally consistent and may reset when isolates are evicted,
// restarted, or cold-started. Do not treat this ledger as durable telemetry,
// billing data, or a global source of truth.
const BANDWIDTH_LEDGER = {
  totalUpstreamBytes: 0,
  totalCompressedBytes: 0,
  totalImages: 0,
  totalSavings: 0
};

// EPHEMERAL ISOLATE STATE:
// Per-isolate response-time samples used for adaptive timeouts.
// Resets may cause timeout estimates to temporarily revert to conservative defaults.
const DOMAIN_RESPONSE_TIMES = new Map();

// EPHEMERAL ISOLATE STATE:
// Per-isolate circuit breaker state.
// Resets may reopen previously failing circuits until failures are re-observed.
const CIRCUIT_BREAKERS = new Map();

// EPHEMERAL ISOLATE STATE:
// Per-isolate rate limit counters.
// These are not globally coordinated across all Worker isolates.
const RATE_LIMITS = new Map();
const RATE_LIMIT_WINDOW_MS = 60000;
const RATE_LIMIT_MAX_FRONT_DOOR = 300;
const RATE_LIMIT_MAX_PURGE = 10;
const RATE_LIMIT_MAX_RAW = 120;

let RATE_LIMIT_LAST_CLEANUP = 0;
const RATE_LIMIT_CLEANUP_INTERVAL_MS = 10000;
const RATE_LIMIT_MAX_MEMORY_ENTRIES = 5000;

function cleanupRateLimits(now, force = false) {
  if (
    !force &&
    now - RATE_LIMIT_LAST_CLEANUP < RATE_LIMIT_CLEANUP_INTERVAL_MS &&
    RATE_LIMITS.size <= RATE_LIMIT_MAX_MEMORY_ENTRIES
  ) {
    return;
  }

  RATE_LIMIT_LAST_CLEANUP = now;

  for (const [key, entry] of RATE_LIMITS) {
    if (now - entry.windowStart > RATE_LIMIT_WINDOW_MS) {
      RATE_LIMITS.delete(key);
    }
  }
}

function hasKvRateLimit() {
  return typeof RATE_LIMIT_KV !== 'undefined' && RATE_LIMIT_KV;
}

function getRateLimitWindowStart(now) {
  return Math.floor(now / RATE_LIMIT_WINDOW_MS) * RATE_LIMIT_WINDOW_MS;
}

function sanitizeRateLimitKey(key) {
  return String(key || '').replace(/[^a-zA-Z0-9:_-]/g, '_');
}

async function kvCheckRateLimit(key, max) {
  const now = Date.now();
  const windowStart = getRateLimitWindowStart(now);
  const kvKey = `rl:${sanitizeRateLimitKey(key)}:${windowStart}`;
  const ttl = Math.max(60, Math.ceil((RATE_LIMIT_WINDOW_MS + 5000) / 1000));

  const raw = await RATE_LIMIT_KV.get(kvKey);
  const current = parseInt(raw, 10);
  const next = Number.isFinite(current) ? current + 1 : 1;

  await RATE_LIMIT_KV.put(kvKey, String(next), { expirationTtl: ttl });

  return next <= max;
}

function memoryCheckRateLimit(key, max) {
  const now = Date.now();

  cleanupRateLimits(now);

  let entry = RATE_LIMITS.get(key);

  if (entry && now - entry.windowStart > RATE_LIMIT_WINDOW_MS) {
    RATE_LIMITS.delete(key);
    entry = undefined;
  }

  if (!entry) {
    entry = {
      count: 0,
      windowStart: now
    };
  }

  if (now - entry.windowStart > RATE_LIMIT_WINDOW_MS) {
    entry.count = 0;
    entry.windowStart = now;
  }

  entry.count++;

  // LRU refresh: move this key to the newest position.
  RATE_LIMITS.delete(key);
  RATE_LIMITS.set(key, entry);

  if (RATE_LIMITS.size > RATE_LIMIT_MAX_MEMORY_ENTRIES) {
    cleanupRateLimits(now, true);

    while (RATE_LIMITS.size > RATE_LIMIT_MAX_MEMORY_ENTRIES) {
      const oldest = RATE_LIMITS.keys().next().value;
      if (oldest === undefined) break;
      RATE_LIMITS.delete(oldest);
    }
  }

  return entry.count <= max;
}

async function checkRateLimit(key, max) {
  if (hasKvRateLimit()) {
    try {
      return await kvCheckRateLimit(key, max);
    } catch {
      // Fall back to in-memory limiting if KV fails.
    }
  }

  return memoryCheckRateLimit(key, max);
}

function trimMap(map, max = MAX_TRACKED_DOMAINS) {
  while (map.size > max) {
    const oldest = map.keys().next().value;
    if (oldest === undefined) break;
    map.delete(oldest);
  }
}

function recordResponseTime(domain, responseTimeMs) {
  if (!DOMAIN_RESPONSE_TIMES.has(domain)) {
    DOMAIN_RESPONSE_TIMES.set(domain, []);
  }

  const times = DOMAIN_RESPONSE_TIMES.get(domain);
  times.push(responseTimeMs);

  if (times.length > MAX_RESPONSE_SAMPLES) {
    times.shift();
  }

  trimMap(DOMAIN_RESPONSE_TIMES);
}

function percentile(arr, p) {
  if (!Array.isArray(arr) || arr.length === 0) return 0;

  const sorted = [...arr].sort((a, b) => a - b);
  const index = Math.min(sorted.length - 1, Math.floor(p * sorted.length));

  return sorted[index];
}

function getAdaptiveTimeout(domain) {
  const times = DOMAIN_RESPONSE_TIMES.get(domain);

  if (!times || times.length === 0) {
    return 30000;
  }

  const avg = times.reduce((sum, t) => sum + t, 0) / times.length;
  const p90 = percentile(times, 0.9);

  const base = Math.max(avg, p90);

  return Math.min(Math.max(base * 3 + 5000, 5000), 50000);
}

const FAILURE_THRESHOLD = 3;
const COOLDOWN_MS = 60000;

function getCircuitState(domain) {
  return CIRCUIT_BREAKERS.get(domain) || {
    failures: 0,
    openedAt: 0
  };
}

function recordSuccess(domain) {
  CIRCUIT_BREAKERS.delete(domain);
  trimMap(CIRCUIT_BREAKERS);
}

function recordFailure(domain) {
  const state = getCircuitState(domain);
  state.failures++;

  if (state.failures >= FAILURE_THRESHOLD) {
    state.openedAt = Date.now();
  }

  CIRCUIT_BREAKERS.set(domain, state);
  trimMap(CIRCUIT_BREAKERS);
}

function isCircuitOpen(domain) {
  const state = getCircuitState(domain);

  if (state.failures >= FAILURE_THRESHOLD) {
    const elapsed = Date.now() - state.openedAt;
    return elapsed < COOLDOWN_MS;
  }

  return false;
}

function getHealthScore(domain) {
  const circuitState = getCircuitState(domain);

  if (circuitState.failures >= FAILURE_THRESHOLD) {
    const elapsed = Date.now() - circuitState.openedAt;
    if (elapsed < COOLDOWN_MS) {
      return 0;
    }
  }

  let score = 100;
  score -= circuitState.failures * 20;

  const times = DOMAIN_RESPONSE_TIMES.get(domain);

  if (times && times.length > 0) {
    const avg = times.reduce((sum, t) => sum + t, 0) / times.length;

    if (avg > 5000) score -= 20;
    else if (avg > 2000) score -= 10;
  }

  return Math.max(0, Math.min(100, score));
}

// ============================================================
// SSRF GUARD
// ============================================================

const BLOCKED_HOST_SUFFIXES = [
  '.local',
  '.localhost',
  '.internal',
  '.invalid',
  '.home.arpa',
  '.arpa',
  '.onion',
  '.i2p',
  '.exit'
];

const AUTH_PARAMS = [
  'api',
  'apikey',
  'api_key'
];

const FORMAT_HINTS = [
  'avif',
  'webp',
  'jpeg'
];

const INTERNAL_FORMAT_PARAM = '__bw_fmt';

function isPrivateIPv4(ip) {
  const parts = String(ip).split('.');

  if (parts.length !== 4) return false;

  const nums = [];

  for (const part of parts) {
    if (!/^\d+$/.test(part)) return false;

    if (part.length > 1 && part.startsWith('0')) return true;

    const n = Number(part);

    if (Number.isNaN(n) || n < 0 || n > 255) return false;

    nums.push(n);
  }

  const [a, b] = nums;

  if (a === 127) return true;
  if (a === 0) return true;
  if (a === 10) return true;
  if (a === 172 && b >= 16 && b <= 31) return true;
  if (a === 192 && b === 168) return true;
  if (a === 169 && b === 254) return true;
  if (a === 100 && b >= 64 && b <= 127) return true;
  if (a === 192 && b === 0 && (nums[2] === 0 || nums[2] === 2)) return true;
  if (a === 198 && (b === 18 || b === 19)) return true;
  if (a === 198 && b === 51 && nums[2] === 100) return true;
  if (a === 203 && b === 0 && nums[2] === 113) return true;
  if (a >= 224) return true;

  return false;
}

function isBlockedIPv6(ip) {
  const lower = String(ip).toLowerCase();

  if (lower === '::1' || lower === '::') return true;
  if (lower.startsWith('fe80:')) return true;
  if (lower.startsWith('fc') || lower.startsWith('fd')) return true;

  if (/^2001:(0|0000)(:|$)/.test(lower)) return true;

  if (lower.startsWith('2002:')) return true;

  if (lower.startsWith('64:ff9b:')) return true;

  if (lower.startsWith('ff')) return true;

  const mappedMatch = lower.match(/::ffff:(?:0:)?(\d+\.\d+\.\d+\.\d+)/);
if (mappedMatch && isPrivateIPv4(mappedMatch[1])) return true;
const mappedHexMatch = lower.match(/^::ffff:([0-9a-f]{1,4}):([0-9a-f]{1,4})$/);
if (mappedHexMatch) {
const hi = parseInt(mappedHexMatch[1], 16);
const lo = parseInt(mappedHexMatch[2], 16);
const ipv4 = `${hi >> 8}.${hi & 255}.${lo >> 8}.${lo & 255}`;
if (isPrivateIPv4(ipv4)) return true;
}

  const compatMatch = lower.match(/^::(\d+\.\d+\.\d+\.\d+)$/);
  if (compatMatch && isPrivateIPv4(compatMatch[1])) return true;

  return false;
}

function isBlockedIP(ip) {
  if (String(ip).includes(':')) return isBlockedIPv6(ip);
  return isPrivateIPv4(ip);
}

function normalizeHost(hostname) {
  let host = String(hostname || '').toLowerCase().trim();

  if (host.startsWith('[') && host.endsWith(']')) {
    host = host.slice(1, -1);
  }

  if (host.endsWith('.')) {
    host = host.slice(0, -1);
  }

  return host;
}

function isBlockedHost(host) {
  if (!host) return true;

  if (host === 'localhost' || host === '0.0.0.0' || host === '::' || host === '::1') {
    return true;
  }

  if (BLOCKED_HOST_SUFFIXES.some(suffix => host.endsWith(suffix))) {
    return true;
  }

  if (/^\d+$/.test(host)) return true;
  if (isBlockedIP(host)) return true;

  return false;
}

function isSafeWorkerUrl(input) {
  try {
    const parsed = new URL(input);

    if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
      return false;
    }

    if (parsed.username || parsed.password) {
      return false;
    }

    const host = normalizeHost(parsed.hostname);

    return !isBlockedHost(host);
  } catch {
    return false;
  }
}

// ============================================================
// MIRROR RACING
// ============================================================

function getMirrorRacingMap() {
  const raw = typeof MIRROR_RACING_MAP !== 'undefined' ? MIRROR_RACING_MAP : '';

  if (!raw) return null;

  if (typeof raw === 'object' && !Array.isArray(raw)) {
    return raw;
  }

  try {
    const parsed = JSON.parse(String(raw));
    return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : null;
  } catch {
    return null;
  }
}

const MIRROR_RACING_MAP_PARSED = getMirrorRacingMap();

function getConfiguredMirrors(hostname) {
  if (!MIRROR_RACING_MAP_PARSED) return [];

  const entry = MIRROR_RACING_MAP_PARSED[hostname];
  if (!Array.isArray(entry)) return [];

  const mirrors = [];

  for (const mirror of entry) {
    const host = normalizeHost(String(mirror || ''));

    if (
      host &&
      host !== hostname &&
      isSafeWorkerUrl(`https://${host}/probe`)
    ) {
      mirrors.push(host);
    }
  }

  return mirrors.slice(0, 2);
}

function detectMirrors(hostname) {
  if (!ENABLE_MIRROR_RACING) return [hostname];

  const configured = getConfiguredMirrors(hostname);

  if (configured.length === 0) {
    return [hostname];
  }

  return [hostname, ...configured].slice(0, 3);
}

async function raceMirrors(mirrors, path, headers) {
  if (!ENABLE_MIRROR_RACING) return mirrors[0];

  const promises = mirrors.map(async mirror => {
    const url = `https://${mirror}${path}`;
    const start = Date.now();
    const healthScore = getHealthScore(mirror);

    try {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 3000);

      const res = await fetch(url, {
        method: 'HEAD',
        headers,
        redirect: 'follow',
        signal: controller.signal
      });

      clearTimeout(timer);

      const elapsed = Date.now() - start;

      return {
        mirror,
        elapsed,
        ok: res.ok,
        healthScore
      };
    } catch {
      return {
        mirror,
        elapsed: Infinity,
        ok: false,
        healthScore
      };
    }
  });

  const results = await Promise.all(promises);
  const successful = results.filter(r => r.ok);

  if (successful.length === 0) {
    return mirrors[0];
  }

  successful.sort((a, b) => {
    if (b.healthScore !== a.healthScore) return b.healthScore - a.healthScore;
    return a.elapsed - b.elapsed;
  });

  return successful[0].mirror;
}

// ============================================================
// SAFE FETCH WITH MANUAL REDIRECT WALK
// ============================================================

async function safeFetch(targetUrl, fetchOptions, maxRedirects = 5, timeoutMs = 15000) {
  let currentUrl = targetUrl;

  for (let i = 0; i <= maxRedirects; i++) {
    if (!isSafeWorkerUrl(currentUrl)) {
      return jsonResponse({ error: 'Blocked URL' }, {
        status: 403
      });
    }

    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);

    let response;

    try {
      response = await fetch(currentUrl, {
        ...fetchOptions,
        redirect: 'manual',
        signal: controller.signal
      });
    } finally {
      clearTimeout(timer);
    }

    if ([301, 302, 303, 307, 308].includes(response.status)) {
      const location = response.headers.get('Location');

      if (!location) {
        return response;
      }

      if (response.body) {
        await response.body.cancel().catch(() => {});
      }

      try {
        currentUrl = new URL(location, currentUrl).toString();
      } catch {
        return jsonResponse({ error: 'Invalid redirect' }, {
          status: 502
        });
      }

      continue;
    }

    return response;
  }

  return jsonResponse({ error: 'Too many redirects' }, {
    status: 508
  });
}

async function fetchWithRetry(fetchFn, maxRetries = 3) {
  let lastError;
  let lastResponse;

  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      const response = await fetchFn();
  const retryCt = String(response.headers.get('content-type') || '');
  const isSyntheticError = retryCt.startsWith('application/json') && response.status >= 500;
  if (response.status >= 500 && attempt < maxRetries && !isSyntheticError) {
lastResponse = response;
if (response.body) await response.body.cancel().catch(() => {});
    const baseDelay = 100 * Math.pow(2, attempt);
        const jitter = Math.random() * 50;

        await new Promise(resolve => setTimeout(resolve, baseDelay + jitter));
        continue;
      }

      return response;
    } catch (err) {
      lastError = err;

      if (attempt < maxRetries) {
        const baseDelay = 100 * Math.pow(2, attempt);
        const jitter = Math.random() * 50;

        await new Promise(resolve => setTimeout(resolve, baseDelay + jitter));
      }
    }
  }

  if (lastError) throw lastError;
  if (lastResponse) return lastResponse;

  return jsonResponse({ error: 'Max retries exceeded' }, {
    status: 502
  });
}

// ============================================================
// CACHE KEY LOGIC
// ============================================================

function sanitizeCacheUrl(cacheUrl) {
  if (!cacheUrl.searchParams.has('url')) {
    for (const param of AUTH_PARAMS) {
      const authGarbage = cacheUrl.searchParams.get(param) || '';
      const urlMatch = authGarbage.match(/[?&]url=([^&]+)/);

      if (urlMatch) {
        try {
          cacheUrl.searchParams.set('url', decodeURIComponent(urlMatch[1]));
          break;
        } catch {}
      }
    }
  }

  for (const param of AUTH_PARAMS) {
    cacheUrl.searchParams.delete(param);
  }

  cacheUrl.searchParams.delete('purge_key');
   cacheUrl.searchParams.delete('key');
   cacheUrl.searchParams.delete('warm');
   cacheUrl.searchParams.delete('debug');
   cacheUrl.searchParams.delete(INTERNAL_FORMAT_PARAM);

  return cacheUrl;
}

function getFormatHint(searchParams, acceptHeader) {
  if (isTruthy(searchParams.get('jpeg'))) return 'jpeg';
  if (isTruthy(searchParams.get('avif'))) return 'avif';
  if (isTruthy(searchParams.get('webp'))) return 'webp';

  if (isTruthy(ALLOW_FALLBACK)) {
    const accept = String(acceptHeader || '').toLowerCase();

    const wantsJpeg = accept.includes('image/jpeg');
    const wantsWebp = accept.includes('image/webp');
    const wantsAvif = accept.includes('image/avif');
    const isWildcard = !accept || accept === '*/*' || accept.includes('*/*');

    if (wantsJpeg && !wantsAvif && !wantsWebp && !isWildcard) return 'jpeg';
    if (wantsWebp && !wantsAvif) return 'webp';

    return 'avif';
  }

  return 'avif';
}

function getCacheTtl(requestUrl, responseHeaders) {
  const upstreamCacheControl = String(responseHeaders?.get('cache-control') || '').toLowerCase();

  if (/no-store|private|no-cache/.test(upstreamCacheControl)) {
    return 0;
  }

  const upstreamMaxAge = parseInt(responseHeaders?.get('x-upstream-max-age') || '0', 10);

  if (upstreamMaxAge > 0) {
    const cappedMaxAge = Math.min(upstreamMaxAge, 30 * 24 * 60 * 60);
    return cappedMaxAge;
  }

  try {
    const u = new URL(requestUrl);
    const target = u.searchParams.get('url');

    if (!target) return 3600;

    const targetUrl = new URL(target);
    const path = targetUrl.pathname.toLowerCase();

    if (/\.(jpe?g|png|webp|avif|gif|bmp|ico)$/i.test(path)) return 604800;

    if (
      path.includes('/wp-content/') ||
      path.includes('/cdn/') ||
      path.includes('/media/') ||
      path.includes('/uploads/')
    ) {
      return 604800;
    }

    return 3600;
  } catch {
    return 3600;
  }
}

function isSaveDataRequest(request) {
  const raw = request.headers.get('save-data') || request.headers.get('sec-ch-save-data') || '';
  return ['1', 'true', 'yes', 'on'].includes(String(raw).trim().toLowerCase()) ? '1' : '0';
}

function buildCacheKey(request) {
  const cacheUrl = new URL(request.url);

  sanitizeCacheUrl(cacheUrl);

  const formatHint = getFormatHint(
    cacheUrl.searchParams,
    request.headers.get('Accept')
  );

  cacheUrl.searchParams.set('_cf_fmt', formatHint);
  cacheUrl.searchParams.set('_cf_sd', isSaveDataRequest(request));
  cacheUrl.searchParams.sort();

  const cacheVersion = getCacheVersion();
  const syntheticUrl = `https://v${cacheVersion}.cache.internal${cacheUrl.pathname}${cacheUrl.search}`;

  return new Request(syntheticUrl, {
    method: 'GET'
  });
}

function buildPurgeKey(requestUrl, formatHint, saveData = '0') {
  const cacheUrl = new URL(requestUrl);

  sanitizeCacheUrl(cacheUrl);

  cacheUrl.searchParams.set('_cf_fmt', formatHint);
  cacheUrl.searchParams.set('_cf_sd', saveData);
  cacheUrl.searchParams.sort();

  const cacheVersion = getCacheVersion();
  const syntheticUrl = `https://v${cacheVersion}.cache.internal${cacheUrl.pathname}${cacheUrl.search}`;

  return new Request(syntheticUrl, {
    method: 'GET'
  });
}

// ============================================================
// MAIN HANDLER
// ============================================================

async function handleRequest(request, event) {
  const requestId = crypto.randomUUID();

  try {
    if (request.method !== 'GET') {
      return jsonResponse({ error: 'Method Not Allowed' }, {
        status: 405,
        headers: {
          'Allow': 'GET',
          'X-Request-ID': requestId
        }
      });
    }

    const url = new URL(request.url);

    let cache = null;

    try {
      cache = caches.default;
    } catch {
      cache = null;
    }

    const userKey = typeof USER_KEY === 'string' ? USER_KEY : '';
    const vercelUrl = normalizeBaseUrl(typeof VERCEL_URL === 'string' ? VERCEL_URL : '');
    const vercelServiceKey = typeof VERCEL_SERVICE_KEY === 'string' ? VERCEL_SERVICE_KEY : '';

    // --------------------------------------------------------
    // HEALTH
    // --------------------------------------------------------
    if (url.pathname === '/healthz' || url.pathname === '/health') {
      return jsonResponse({
        status: 'ok',
        source: 'cloudflare-worker',
        requestId
      }, {
        headers: {
          'Cache-Control': 'no-store',
          'X-Request-ID': requestId
        }
      });
    }

    // --------------------------------------------------------
    // /stats
    // --------------------------------------------------------
    if (url.pathname === '/stats') {
      if (!userKey) {
        return jsonResponse({ error: 'Worker misconfigured: USER_KEY is missing' }, {
          status: 500,
          headers: { 'X-Request-ID': requestId }
        });
      }

      const headerKey = request.headers.get('x-api-key') || '';
      const queryKey =
        url.searchParams.get('api') ||
        url.searchParams.get('apikey') ||
        url.searchParams.get('api_key') ||
        '';

      let authorized = false;

      for (const candidate of [headerKey, queryKey]) {
        const cleanKey = String(candidate || '').split(/[\/\?]/)[0].trim();

        if (cleanKey && await safeCompare(cleanKey, userKey)) {
          authorized = true;
          break;
        }
      }

      if (!authorized) {
        return jsonResponse({ error: 'Access Denied' }, {
          status: 401,
          headers: { 'X-Request-ID': requestId }
        });
      }

      const savingsPercent = BANDWIDTH_LEDGER.totalUpstreamBytes > 0
        ? ((BANDWIDTH_LEDGER.totalSavings / BANDWIDTH_LEDGER.totalUpstreamBytes) * 100).toFixed(2)
        : '0.00';

      return jsonResponse({
        ...BANDWIDTH_LEDGER,
        savingsPercent: `${savingsPercent}%`,
        stateWarning: 'ephemeral-isolate-only',
        requestId
      }, {
        headers: {
          'Cache-Control': 'no-store',
          'X-Request-ID': requestId
        }
      });
    }

    // --------------------------------------------------------
    // /omega
    // --------------------------------------------------------
    if (url.pathname === '/omega') {
      return jsonResponse({
        error: 'Omega Purge is disabled for workers.dev domains. Use CACHE_VERSION env var instead.'
      }, {
        status: 501,
        headers: { 'X-Request-ID': requestId }
      });
    }

    // --------------------------------------------------------
    // /raw
    // --------------------------------------------------------
    if (url.pathname === '/raw') {
      const internalKey = typeof INTERNAL_KEY === 'string' ? INTERNAL_KEY : '';

      if (!internalKey) {
        return jsonResponse({ error: 'Worker misconfigured: INTERNAL_KEY is missing' }, {
          status: 500,
          headers: { 'X-Request-ID': requestId }
        });
      }

      const token = request.headers.get('x-internal-key');

      if (!token || !await safeCompare(token, internalKey)) {
        return jsonResponse({ error: 'Unauthorized Back-channel' }, {
          status: 401,
          headers: { 'X-Request-ID': requestId }
        });
      }

      const rawClientKey = request.headers.get('cf-connecting-ip') || 'unknown';
      if (!await checkRateLimit(`raw:${rawClientKey}`, RATE_LIMIT_MAX_RAW)) {
        return jsonResponse({ error: 'Rate limit exceeded' }, {
          status: 429,
          headers: { 'X-Request-ID': requestId, 'Retry-After': '60' }
        });
      }

      const targetUrl = url.searchParams.get('url');
if (!targetUrl) {
return jsonResponse({ error: 'Missing url' }, {
status: 400,
headers: { 'X-Request-ID': requestId }
});
}
if (!isSafeWorkerUrl(targetUrl)) {
return jsonResponse({ error: 'Blocked URL' }, {
status: 403,
headers: { 'X-Request-ID': requestId }
});
}
const rawAllowedDomains = typeof RAW_ALLOWED_DOMAINS === 'string' && RAW_ALLOWED_DOMAINS
  ? RAW_ALLOWED_DOMAINS.split(',').map(d => normalizeHost(d)).filter(Boolean)
  : [];

if (rawAllowedDomains.length === 0) {
  return jsonResponse({ error: 'Worker misconfigured: RAW_ALLOWED_DOMAINS is required for /raw' }, {
    status: 403,
    headers: { 'X-Request-ID': requestId }
  });
}

const rawTargetHost = normalizeHost(new URL(targetUrl).hostname);
if (!rawAllowedDomains.some(d => rawTargetHost === d || rawTargetHost.endsWith('.' + d))) {
  return jsonResponse({ error: 'Domain not in RAW_ALLOWED_DOMAINS' }, {
    status: 403,
    headers: { 'X-Request-ID': requestId }
  });
}

      let parsedTarget;

      try {
        parsedTarget = new URL(targetUrl);
      } catch {
        return jsonResponse({ error: 'Invalid URL' }, {
          status: 400,
          headers: { 'X-Request-ID': requestId }
        });
      }

      const domain = parsedTarget.hostname;

      if (isCircuitOpen(domain)) {
        emitTelemetry('CIRCUIT_BREAKER_OPEN', {
          domain,
          requestId
        });

        return jsonResponse({ error: 'Circuit breaker open' }, {
          status: 503,
          headers: { 'X-Request-ID': requestId }
        });
      }

      let finalUrl = targetUrl;

      if (ENABLE_MIRROR_RACING) {
        const mirrors = detectMirrors(domain);

        if (mirrors.length > 1) {
          const path = parsedTarget.pathname + parsedTarget.search;

          const raceHeaders = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36'
          };

          const winner = await raceMirrors(mirrors, path, raceHeaders);

          if (winner && winner !== domain) {
            finalUrl = `https://${winner}${path}`;

            emitTelemetry('MIRROR_RACE', {
              original: domain,
              winner,
              requestId
            });
          }
        }
      }

      const adaptiveTimeout = getAdaptiveTimeout(domain);

      try {
        const startTime = Date.now();

        const response = await fetchWithRetry(async () => {
          return await safeFetch(finalUrl, {
            headers: {
              'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36',
              'Accept': 'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8',
              'Accept-Encoding': 'identity',
              'X-Request-ID': requestId
            }
          }, 5, adaptiveTimeout);
        }, 0); // Vercel's fetchWithBackoff already retries; avoids 4x3 attempt amplification

        const elapsed = Date.now() - startTime;

        recordResponseTime(domain, elapsed);

        if (response.ok || (response.status >= 400 && response.status < 500)) {
          recordSuccess(domain);
        } else if (response.status >= 500) {
          recordFailure(domain);
        }

        const contentLength = parseInt(response.headers.get('content-length') || '0', 10);
if (contentLength > MAX_RAW_FETCH_BYTES) {
if (response.body) {
await response.body.cancel().catch(() => {});
}
return jsonResponse({ error: 'Upstream too large' }, {
status: 413,
headers: { 'X-Request-ID': requestId }
});
}
const rawContentType = String(response.headers.get('content-type') || '');
if (rawContentType && !rawContentType.startsWith('image/') && rawContentType !== 'application/octet-stream') {
if (response.body) {
await response.body.cancel().catch(() => {});
}
return jsonResponse({ error: 'Upstream is not an image' }, {
status: 415,
headers: { 'X-Request-ID': requestId }
});
}
if (!response.body) {
  return jsonResponse({ error: 'Upstream returned empty body' }, {
    status: 502,
    headers: { 'X-Request-ID': requestId }
  });
}

let seenBytes = 0;
const limitedStream = new TransformStream({
transform(chunk, controller) {
seenBytes += chunk.byteLength;
if (seenBytes > MAX_RAW_FETCH_BYTES) {
controller.error(new Error('RAW_BODY_TOO_LARGE'));
return;
}
controller.enqueue(chunk);
}
});
const limitedHeaders = new Headers(response.headers);
limitedHeaders.set('X-Request-ID', requestId);
return new Response(response.body.pipeThrough(limitedStream), {
status: response.status,
statusText: response.statusText,
headers: limitedHeaders
});
      } catch {
        recordFailure(domain);

        return jsonResponse({ error: 'Upstream fetch failed' }, {
          status: 502,
          headers: { 'X-Request-ID': requestId }
        });
      }
    }

    // --------------------------------------------------------
    // /purge
    // --------------------------------------------------------
    if (url.pathname === '/purge') {
      const configuredPurgeKey =
        typeof PURGE_KEY === 'string' && PURGE_KEY
          ? PURGE_KEY
          : null;

      if (!configuredPurgeKey) {
        return jsonResponse({
          error: 'Worker misconfigured: PURGE_KEY is missing. Purging disabled.'
        }, {
          status: 501,
          headers: { 'X-Request-ID': requestId }
        });
      }

      const purgeClientKey = request.headers.get('cf-connecting-ip') || 'unknown';
      if (!await checkRateLimit(`purge:${purgeClientKey}`, RATE_LIMIT_MAX_PURGE)) {
        return jsonResponse({ error: 'Rate limit exceeded' }, {
          status: 429,
          headers: { 'X-Request-ID': requestId, 'Retry-After': '60' }
        });
      }

      const headerKey =
        request.headers.get('x-purge-key') ||
        request.headers.get('x-api-key') ||
        '';

      const queryKey =
        url.searchParams.get('purge_key') ||
        url.searchParams.get('key') ||
        '';

      let authorized = false;

      for (const candidate of [headerKey, queryKey]) {
        const cleanKey = String(candidate || '').split(/[\/\?]/)[0].trim();

        if (cleanKey && await safeCompare(cleanKey, configuredPurgeKey)) {
          authorized = true;
          break;
        }
      }

      if (!authorized) {
        return jsonResponse({ error: 'Access Denied' }, {
          status: 401,
          headers: { 'X-Request-ID': requestId }
        });
      }

      const target =
        url.searchParams.get('request') ||
        url.searchParams.get('target') ||
        url.searchParams.get('url');

      if (!target) {
        return jsonResponse({
          error: 'Missing target. Use ?url=IMAGE_URL or ?request=FULL_WORKER_REQUEST_URL'
        }, {
          status: 400,
          headers: { 'X-Request-ID': requestId }
        });
      }

      let baseUrl;

      try {
        const parsedTarget = new URL(target);

        if (parsedTarget.searchParams.has('url')) {
          baseUrl = target;
        } else {
          baseUrl = `${url.origin}/?url=${encodeURIComponent(target)}`;
        }
      } catch {
        return jsonResponse({ error: 'Invalid target URL' }, {
          status: 400,
          headers: { 'X-Request-ID': requestId }
        });
      }

      let purged = 0;

      if (cache) {
        for (const formatHint of FORMAT_HINTS) {
          for (const saveData of ['0', '1']) {
            try {
              const keyRequest = buildPurgeKey(baseUrl, formatHint, saveData);
              const deleted = await cache.delete(keyRequest);

              if (deleted) {
                purged++;
              }
            } catch {}
          }
        }
      }

      const isWarm = isTruthy(url.searchParams.get('warm'));
      let warmed = false;

        if (isWarm && vercelUrl && userKey && cache) {
        const warmUrl = new URL(baseUrl);
        const warmAccept = request.headers.get('Accept') || '*/*';

        const warmCacheKey = buildCacheKey(new Request(warmUrl.toString(), {
          headers: {
            'Accept': warmAccept
          }
        }));

        // Ensure Vercel returns the exact format expected by the cache key
        const warmFormatHint = getFormatHint(warmUrl.searchParams, warmAccept);
        const warmVercelUrlObj = new URL(joinUrl(vercelUrl, warmUrl.search));
        warmVercelUrlObj.searchParams.delete(INTERNAL_FORMAT_PARAM);
        warmVercelUrlObj.searchParams.set(INTERNAL_FORMAT_PARAM, warmFormatHint);

        warmed = true;

        event.waitUntil(
          (async () => {
            try {
              const vReq = new Request(warmVercelUrlObj.toString(), {
                method: 'GET',
                headers: {
                  'Accept': warmAccept,
                  'Accept-Encoding': 'identity',
                  ...(vercelServiceKey ? { 'x-vercel-service-key': vercelServiceKey } : {})
                }
              });

              const res = await fetchWithTimeout(vReq, 20000);

              if (res.status === 200 && String(res.headers.get('Content-Type')).startsWith('image/') && String(res.headers.get('x-ghost') || '').toLowerCase() !== 'true') {
                const ch = new Headers(res.headers);
                const warmTtl = getCacheTtl(warmUrl.toString(), res.headers);

                if (warmTtl > 0) {
                  ch.set(
                    'Cache-Control',
                    `public, max-age=${warmTtl}, stale-while-revalidate=604800, stale-if-error=604800`
                  );

                  ch.delete('Expires');
                  ch.delete('Pragma');

                  const cacheableResponse = new Response(res.body, {
                    status: res.status,
                    statusText: res.statusText,
                    headers: ch
                  });

                  await cache.put(warmCacheKey, cacheableResponse);
                }
              }
            } catch {}
          })()
        );
      }

      emitTelemetry('CACHE_PURGE', {
        url: sanitizeUrl(baseUrl),
        purged,
        warmed,
        requestId
      });

      return jsonResponse({
     purged,
     warmed,
     formats: FORMAT_HINTS,
     target: baseUrl.split('?')[0],
     requestId
   }, {
        headers: {
          'Cache-Control': 'no-store',
          'X-Request-ID': requestId
        }
      });
    }

    // --------------------------------------------------------
    // FRONT DOOR
    // --------------------------------------------------------

    const frontDoorKey = request.headers.get('cf-connecting-ip') || 'unknown';
    if (!await checkRateLimit(`front:${frontDoorKey}`, RATE_LIMIT_MAX_FRONT_DOOR)) {
      return jsonResponse({ error: 'Rate limit exceeded' }, {
        status: 429,
        headers: { 'X-Request-ID': requestId, 'Retry-After': '60' }
      });
    }

    const trustScore = request.cf?.clientTrustScore ?? 100;

    if (trustScore < 30) {
      emitTelemetry('BOT_TARPIT', {
        url: sanitizeUrl(request.url),
        trustScore,
        requestId
      });

      return new Response(createTarpitStream(), {
  status: 200,
  headers: {
    'Content-Type': 'image/gif',
    'Cache-Control': 'no-store',
    'X-Request-ID': requestId
  }
});
    }

    if (!userKey) {
      return jsonResponse({ error: 'Worker misconfigured: USER_KEY is missing' }, {
        status: 500,
        headers: { 'X-Request-ID': requestId }
      });
    }

    const headerKey = request.headers.get('x-api-key') || '';

    const queryKey =
      url.searchParams.get('api') ||
      url.searchParams.get('apikey') ||
      url.searchParams.get('api_key') ||
      '';

    let authorized = false;

    for (const candidate of [headerKey, queryKey]) {
      const cleanKey = String(candidate || '').split(/[\/\?]/)[0].trim();

      if (cleanKey && await safeCompare(cleanKey, userKey)) {
        authorized = true;
        break;
      }
    }

    if (!authorized) {
      return jsonResponse({ error: 'Access Denied' }, {
        status: 401,
        headers: { 'X-Request-ID': requestId }
      });
    }

    const targetParam = url.searchParams.get('url');
if (targetParam && !isSafeWorkerUrl(targetParam)) {
return jsonResponse({ error: 'Blocked URL' }, {
status: 403,
headers: { 'X-Request-ID': requestId }
});
}
const cacheKey = buildCacheKey(request);
let response = null;

    if (cache) {
      try {
        response = await cache.match(cacheKey);
      } catch {
        response = null;
      }
    }

    if (response) {
      emitTelemetry('CACHE_HIT', {
        url: sanitizeUrl(request.url),
        requestId
      });

      const headers = new Headers(response.headers);
headers.set('X-Cache', 'HIT');
headers.set('X-Request-ID', requestId);
headers.set('Referrer-Policy', 'no-referrer');

      return new Response(response.body, {
        status: response.status,
        statusText: response.statusText,
        headers
      });
    }

    emitTelemetry('CACHE_MISS', {
      url: sanitizeUrl(request.url),
      requestId
    });

    if (!vercelUrl) {
      return jsonResponse({ error: 'Worker misconfigured: VERCEL_URL is missing' }, {
        status: 500,
        headers: { 'X-Request-ID': requestId }
      });
    }

    const vercelHeaders = new Headers();

    const safeHeaders = ['accept', 'accept-language', 'sec-ch-ua', 'sec-ch-ua-mobile', 'sec-ch-ua-platform', 'save-data', 'sec-ch-save-data', 'sec-ch-viewport-width', 'viewport-width', 'sec-ch-dpr', 'dpr'];
    for (const h of safeHeaders) {
      const val = request.headers.get(h);
      if (val) vercelHeaders.set(h, val);
    }

    vercelHeaders.set('Accept-Encoding', 'identity');
    vercelHeaders.set('X-Request-ID', requestId);

    if (vercelServiceKey) {
      vercelHeaders.set('x-vercel-service-key', vercelServiceKey);
    }

    const formatHint = getFormatHint(url.searchParams, request.headers.get('Accept'));
  const upstreamUrlObj = new URL(url.href);
  
  // C-001: Strip auth and admin params before forwarding to Vercel
  const stripParams = ['api', 'apikey', 'api_key', 'key', 'purge_key', 'warm', 'debug'];
  for (const param of stripParams) {
    upstreamUrlObj.searchParams.delete(param);
  }

  upstreamUrlObj.searchParams.delete(INTERNAL_FORMAT_PARAM);
  upstreamUrlObj.searchParams.set(INTERNAL_FORMAT_PARAM, formatHint);
  const upstreamUrl = joinUrl(vercelUrl, upstreamUrlObj.search);

    const vercelRequest = new Request(upstreamUrl, {
      method: 'GET',
      headers: vercelHeaders,
      redirect: 'follow'
    });

    try {
      response = await fetchWithTimeout(vercelRequest, VERCEL_TIMEOUT_MS);
    } catch (err) {
      emitTelemetry('VERCEL_TIMEOUT_NEGOTIATION', {
        url: sanitizeUrl(request.url),
        error: sanitizeError(err),
        requestId
      });

      return jsonResponse({ error: 'Vercel request timed out' }, {
        status: 504,
        headers: { 'X-Request-ID': requestId }
      });
    }

    const contentType = String(response.headers.get('Content-Type') || '');

    if (
      response.status === 200 &&
      contentType.startsWith('image/') &&
      String(response.headers.get('x-ghost') || '').toLowerCase() !== 'true'
    ) {
      const upstreamLength = parseInt(response.headers.get('x-upstream-content-length') || '0', 10);
      const compressedLength = parseInt(response.headers.get('content-length') || '0', 10);

      if (upstreamLength > 0) {
        BANDWIDTH_LEDGER.totalUpstreamBytes += upstreamLength;
        BANDWIDTH_LEDGER.totalImages++;

        if (compressedLength > 0) {
          BANDWIDTH_LEDGER.totalCompressedBytes += compressedLength;
          BANDWIDTH_LEDGER.totalSavings += upstreamLength - compressedLength;
        }
      }

      if (cache) {
        const cacheResponse = response.clone();
        const cacheHeaders = new Headers(cacheResponse.headers);

        const ttl = getCacheTtl(request.url, response.headers);

        if (ttl > 0) {
          cacheHeaders.set(
            'Cache-Control',
            `public, max-age=${ttl}, stale-while-revalidate=604800, stale-if-error=604800`
          );

          cacheHeaders.delete('Expires');
          cacheHeaders.delete('Pragma');

          const targetParam = url.searchParams.get('url');

          if (targetParam) {
            try {
              const targetDomain = new URL(targetParam).hostname;
              cacheHeaders.set('Cache-Tag', `domain:${targetDomain}`);
            } catch {}
          }

          const cacheableResponse = new Response(cacheResponse.body, {
            status: cacheResponse.status,
            statusText: cacheResponse.statusText,
            headers: cacheHeaders
          });

          event.waitUntil(
            cache.put(cacheKey, cacheableResponse).catch(() => {})
          );
        }
      }
    }

    const headers = new Headers(response.headers);
headers.set('X-Cache', 'MISS');
headers.set('X-Request-ID', requestId);
headers.set('Referrer-Policy', 'no-referrer');

    return new Response(response.body, {
      status: response.status,
      statusText: response.statusText,
      headers
    });
  } catch (err) {
    emitTelemetry('WORKER_FATAL', {
      error: sanitizeError(err),
      requestId
    });

    return jsonResponse({ error: 'Worker internal error' }, {
      status: 500,
      headers: { 'X-Request-ID': requestId }
    });
  }
}